package com.malkinfo.ecommerceapps.model

data class User (
          var uid :String? = null,
          var name :String? = null,
          var phoneNumber :String? = null,
          var phoneImage :String? = null,

        )